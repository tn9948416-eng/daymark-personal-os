# DAYMARK 3.0 — kiểm tra kỹ thuật

## Đã kiểm tra trong môi trường mô phỏng

- Đọc dữ liệu tương thích từ `localStorage` key `daymark-v2` của phiên bản 2.1.
- Bắt buộc xác nhận riêng trước khi đăng nhập và đưa snapshot ứng dụng lên Cloud.
- Lưu snapshot đầu tiên qua RPC mô phỏng.
- Chỉnh sửa dữ liệu mới trong khi lần ghi đầu đang chạy; xác nhận lần đồng bộ tiếp theo không làm rơi chỉnh sửa.
- AI không được gọi khi chưa tick đồng ý.
- Payload AI chỉ chứa đúng nhóm dữ liệu được chọn.
- Hội thoại không được gửi theo mặc định; tùy chọn riêng gửi tối đa sáu tin gần nhất hoạt động khi được bật.
- Giao diện AI ở viewport rộng 390 px không tràn ngang.
- Không phát sinh lỗi JavaScript runtime trong lượt kiểm tra trình duyệt mô phỏng.

## Kiểm tra tĩnh

- `node --check` cho JavaScript nhúng trong HTML, `sw.js` và `supabase-config.js`.
- Kiểm tra kiểu TypeScript cho Edge Function bằng TypeScript compiler với khai báo Deno tối thiểu.
- Parse JSON của PWA manifest.
- Kiểm tra bất biến bảo mật cơ bản: không có khóa bí mật trong browser config; Edge Function có `store: false`, kiểm tra lựa chọn dữ liệu và consent lịch sử hội thoại.
- SHA-256 của `archive/index.v2.1-preserved.html` khớp bản 2.1 gốc đã lưu.

## Chưa thể xác minh từ môi trường này

- Chưa chạy migration trên project Supabase thật.
- Chưa deploy Edge Function hoặc gọi OpenAI API thật vì chưa có project/secret do chủ tài khoản cấu hình.
- Chưa kiểm thử trên iPhone vật lý; responsive test mô phỏng ở 390 px không thay thế kiểm thử Safari iOS.

Do vậy đây là gói mã nguồn sẵn sàng cấu hình, không phải một dịch vụ Cloud/AI đã được kết nối với tài khoản cá nhân. Hãy hoàn thành `SETUP_DAYMARK_3.0.md` trước khi đăng nhập và bật đồng bộ.
