# DAYMARK 3.1 — Hướng dẫn cập nhật Focus & Reminders

## 1. Sao lưu trước khi cập nhật

- Trên PC: DAYMARK → Cài đặt → Xuất dữ liệu JSON.
- Trên iPhone: mở app từ Màn hình chính → Cài đặt → Xuất dữ liệu JSON.
- Giữ hai bản sao riêng. Không tải JSON cá nhân lên GitHub Public.
- Bản 3.1 giữ nguyên localStorage key `daymark-v2`; nếu bạn cập nhật đúng website/origin cũ thì dữ liệu hiện có tiếp tục được đọc.

## 2. Cập nhật GitHub Pages

1. Tải và giải nén `DAYMARK-Personal-OS-3.1-Focus-Reminders.zip`.
2. Mở repository GitHub `daymark-personal-os`.
3. Chọn Add file → Upload files.
4. Từ thư mục `DAYMARK-3.1/DAYMARK-3.0`, tải lên và ghi đè các file ở thư mục gốc: `index.html`, `sw.js`, `manifest.webmanifest`, `icon.svg`, `icon-180.png`, `icon-192.png`, `icon-512.png`, `supabase-config.js`, `.nojekyll`.
5. Có thể cập nhật `README.md`. Không tải `archive/`, JSON backup, `.env`, API key hoặc mật khẩu.
6. Commit vào `main`; chờ GitHub Pages deploy thành công.
7. Trên PC tải lại trang. Trên iPhone đóng DAYMARK rồi mở lại từ biểu tượng Màn hình chính để nhận service worker cache mới.

## 3. Dùng chế độ tập trung

1. Mở mục **Tập trung**.
2. Chọn 15, 25, 45 hoặc 60 phút.
3. Nhập nội dung đang làm (ví dụ: “Ôn Aptis Listening”).
4. Nhấn **Bắt đầu tập trung**.
5. DAYMARK mở màn hình Deep Work phủ vùng hiển thị, đếm ngược, hiển thị tiến độ và lời nhắc tinh thần.
6. Nếu thiết bị hỗ trợ, app xin Screen Wake Lock để giữ màn hình không tự tắt khi vẫn đang mở ở foreground.
7. Hết giờ, app hiển thị màn hình hoàn thành, phát chuông nếu trình duyệt cho phép và gửi thông báo nếu đã cấp quyền.

### Trên iPhone

- Dùng DAYMARK từ biểu tượng đã thêm vào Màn hình chính (PWA), không phải tab Safari.
- Screen Wake Lock cho Home Screen web apps được hỗ trợ từ iOS/iPadOS 18.4, nhưng còn phụ thuộc thiết bị/trình duyệt cấp quyền.
- Không bấm nút nguồn để khóa máy khi cần đồng hồ tiếp tục hiển thị. PWA không thể giữ đồng hồ chạy trên Lock Screen hoặc Dynamic Island.
- DAYMARK không thể tự bật Không làm phiền. Vuốt từ góc phải phía trên xuống → Focus → Do Not Disturb. Có thể cài lịch Focus trong Cài đặt iPhone.

## 4. Thêm giờ nhắc cho công việc

1. Vào **Công việc** → thêm hoặc sửa nhiệm vụ.
2. Tại **Nhắc vào thời điểm**, chọn ngày và giờ.
3. Lưu nhiệm vụ.
4. Vào mục **Nhắc việc**.
5. Bấm **Bật thông báo DAYMARK** và chọn Allow.
6. Khi DAYMARK đang chạy, app kiểm tra thời điểm nhắc và hiển thị thông báo/nhắc trong app.

### Muốn iPhone báo khi DAYMARK đóng

1. Vào **Nhắc việc**.
2. Bấm **Thêm vào Lịch** cho từng nhiệm vụ hoặc **Xuất tất cả sang Lịch (.ics)**.
3. Nếu iPhone mở bảng chia sẻ, chọn Lưu vào Tệp hoặc mở bằng Lịch/Calendar nếu có.
4. Nếu lưu vào Tệp, mở file `.ics` trong ứng dụng Tệp rồi thêm sự kiện vào Apple Calendar.
5. Kiểm tra sự kiện đã xuất hiện trong Lịch và có cảnh báo (Alert) tại thời điểm bắt đầu.

DAYMARK 3.1 không có máy chủ Push để đánh thức app khi nó đóng hoàn toàn. Vì thế Apple Calendar là phương án miễn phí để hệ điều hành tự báo giờ khi DAYMARK không chạy.

## 5. AI và chi phí

- AI API trả phí được tạm dừng theo yêu cầu.
- Coach sử dụng quy tắc cục bộ, không gọi OpenAI API.
- Focus, nhắc việc và xuất `.ics` không cần API key hoặc thanh toán.
- Supabase Cloud Sync hiện có chỉ hoạt động nếu bạn đã cấu hình trước; các tính năng mới vẫn chạy local nếu chưa có Cloud.

## 6. Khắc phục sự cố

- Không thấy mục Nhắc việc: kiểm tra đã tải `index.html` bản 3.1 và nhấn tải lại sau khi GitHub Pages deploy.
- Không thấy thông báo trên iPhone: mở DAYMARK từ biểu tượng Màn hình chính, vào Nhắc việc và bấm cấp quyền.
- Không giữ sáng: kiểm tra thiết bị hỗ trợ Wake Lock, giảm chế độ tiết kiệm pin và giữ app ở foreground.
- Không có chuông khi hết giờ: kiểm tra âm lượng, chế độ im lặng, quyền âm thanh/trình duyệt và không khóa máy; thông báo hệ thống có thể bị Focus/DND làm im lặng.
