-- DAYMARK 3.0 — private per-user cloud state + optimistic concurrency + AI quota
-- Run this entire file in Supabase Dashboard → SQL Editor.

create table if not exists public.daymark_states (
  user_id uuid primary key references auth.users(id) on delete cascade,
  state_data jsonb not null check (jsonb_typeof(state_data) = 'object'),
  updated_at timestamptz not null default clock_timestamp()
);

alter table public.daymark_states enable row level security;
revoke all on table public.daymark_states from public, anon, authenticated;
grant select on table public.daymark_states to authenticated;

drop policy if exists "Users can read only their own DAYMARK state" on public.daymark_states;
create policy "Users can read only their own DAYMARK state"
  on public.daymark_states for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Users can insert only their own DAYMARK state" on public.daymark_states;
drop policy if exists "Users can update only their own DAYMARK state" on public.daymark_states;

-- A compare-and-swap save prevents a second device from silently overwriting a newer snapshot.
create or replace function public.save_daymark_state(
  p_state jsonb,
  p_expected_updated_at timestamptz default null
)
returns table (
  saved boolean,
  conflict boolean,
  state_data jsonb,
  updated_at timestamptz
)
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_uid uuid := auth.uid();
  v_current_state jsonb;
  v_current_updated timestamptz;
  v_new_updated timestamptz;
begin
  if v_uid is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;
  if p_state is null or jsonb_typeof(p_state) <> 'object' then
    raise exception 'DAYMARK state must be a JSON object' using errcode = '22023';
  end if;
  if pg_column_size(p_state) > 2097152 then
    raise exception 'DAYMARK state exceeds the 2 MB safety limit' using errcode = '22023';
  end if;

  -- Serialize first insert/update attempts by user, including when no row exists yet.
  perform pg_advisory_xact_lock(hashtextextended(v_uid::text, 0));

  select ds.state_data, ds.updated_at
    into v_current_state, v_current_updated
    from public.daymark_states as ds
    where ds.user_id = v_uid
    for update;

  if not found then
    if p_expected_updated_at is not null then
      return query select false, true, null::jsonb, null::timestamptz;
      return;
    end if;

    v_new_updated := clock_timestamp();
    insert into public.daymark_states(user_id, state_data, updated_at)
      values (v_uid, p_state, v_new_updated);
    return query select true, false, p_state, v_new_updated;
    return;
  end if;

  if p_expected_updated_at is null or p_expected_updated_at <> v_current_updated then
    return query select false, true, v_current_state, v_current_updated;
    return;
  end if;

  v_new_updated := clock_timestamp();
  update public.daymark_states as ds
    set state_data = p_state, updated_at = v_new_updated
    where ds.user_id = v_uid;
  return query select true, false, p_state, v_new_updated;
end;
$$;

revoke all on function public.save_daymark_state(jsonb, timestamptz) from public, anon;
grant execute on function public.save_daymark_state(jsonb, timestamptz) to authenticated;

-- AI quota counters are intentionally not exposed to browser clients.
create table if not exists public.daymark_ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_day date not null default (timezone('utc', now())::date),
  requests integer not null default 0 check (requests >= 0),
  primary key (user_id, usage_day)
);
alter table public.daymark_ai_usage enable row level security;
revoke all on table public.daymark_ai_usage from public, anon, authenticated;

create or replace function public.consume_daymark_ai_request(p_daily_limit integer default 15)
returns table (allowed boolean, used integer, usage_day date)
language plpgsql
security definer
set search_path = pg_catalog, public
as $$
declare
  v_uid uuid := auth.uid();
  v_day date := timezone('utc', now())::date;
  v_limit integer := greatest(1, least(coalesce(p_daily_limit, 15), 100));
  v_used integer;
begin
  if v_uid is null then
    raise exception 'Authentication required' using errcode = '42501';
  end if;

  -- The WHERE clause prevents increment after the limit. If it updates no row,
  -- RETURNING sets NOT FOUND and the request is denied (including at exactly the limit).
  insert into public.daymark_ai_usage(user_id, usage_day, requests)
    values (v_uid, v_day, 1)
  on conflict (user_id, usage_day) do update
    set requests = public.daymark_ai_usage.requests + 1
    where public.daymark_ai_usage.requests < v_limit
  returning requests into v_used;

  if not found then
    select requests into v_used
      from public.daymark_ai_usage
      where daymark_ai_usage.user_id = v_uid and daymark_ai_usage.usage_day = v_day;
    return query select false, coalesce(v_used, v_limit), v_day;
    return;
  end if;

  return query select true, v_used, v_day;
end;
$$;

revoke all on function public.consume_daymark_ai_request(integer) from public, anon;
grant execute on function public.consume_daymark_ai_request(integer) to authenticated;

-- Enable Realtime for cloud state updates on other signed-in devices.
do $$
begin
  alter publication supabase_realtime add table public.daymark_states;
exception
  when duplicate_object then null;
  when undefined_object then
    raise notice 'Publication supabase_realtime was not found; enable Realtime for daymark_states in the Dashboard.';
end;
$$;

alter table public.daymark_states replica identity full;
