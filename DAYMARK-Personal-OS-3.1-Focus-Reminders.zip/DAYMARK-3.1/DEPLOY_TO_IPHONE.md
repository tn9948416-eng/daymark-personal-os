# Cập nhật DAYMARK 3.0 trên iPhone

Bạn đã có DAYMARK 2.1 chạy trên GitHub Pages và đã thêm vào Màn hình chính iPhone. **Không cần tạo repository mới.** Hãy dùng repository hiện tại `tn9948416-eng/daymark-personal-os` và URL hiện tại:

`https://tn9948416-eng.github.io/daymark-personal-os/`

## 1. Sao lưu trước khi cập nhật

Trên cả máy tính và iPhone, mở DAYMARK 2.1 → Cài đặt → Xuất dữ liệu (JSON). Lưu riêng hai file backup ở nơi riêng tư. Không tải backup lên GitHub. Giữ lại bản 2.1 cũ; gói 3.0 cũng kèm `index.v2.1-preserved.html` để tham chiếu.

## 2. Cập nhật repository hiện tại

1. Giải nén gói DAYMARK 3.0 trên máy tính.
2. Trong thư mục `DAYMARK-3.0`, chỉ tải các file frontend sau lên **thư mục gốc** repository hiện tại: `index.html`, `supabase-config.js`, `manifest.webmanifest`, `sw.js`, `icon.svg`, `icon-180.png`, `icon-192.png`, `icon-512.png`, `.nojekyll`, `README.md`, `SETUP_DAYMARK_3.0.md`, `DEPLOY_TO_IPHONE.md`.
3. Không upload `.env`, file backup JSON, `index.v1.backup.html` hoặc `index.v2.1-preserved.html` lên repository Public. Có thể giữ thư mục `supabase/` trong repo để quản lý mã nguồn SQL/Edge Function, nhưng tuyệt đối không đưa secrets vào đó.
4. Trước khi đăng nhập Cloud, hãy hoàn thành cấu hình Supabase theo `SETUP_DAYMARK_3.0.md`. File `supabase-config.js` cần có Project URL và publishable/anon key; tuyệt đối không dùng secret/service_role key.
5. Nhấn Commit changes và đợi GitHub Pages deploy xong.

## 3. Cài hoặc cập nhật biểu tượng trên iPhone

Nếu đã thêm DAYMARK 2.1 vào Home Screen, thường không cần thêm biểu tượng lần nữa: mở biểu tượng cũ sau khi Pages deploy xong. Đóng hẳn PWA, mở URL trên bằng Safari và refresh; sau đó mở lại biểu tượng. Nếu vẫn thấy giao diện cũ, đóng PWA, refresh trang Safari thêm lần nữa để service worker nhận cache mới.

Nếu chưa cài: mở URL bằng Safari → Share → Add to Home Screen → bật Open as Web App nếu tùy chọn có mặt → Add.

Hướng dẫn Apple: https://support.apple.com/guide/iphone/open-as-web-app-iphea86e5236/ios

## 4. Đăng nhập đồng bộ giữa máy tính và iPhone

1. Đăng nhập cùng một tài khoản Supabase trên cả hai thiết bị.
2. Lần đăng nhập đầu tiên sẽ yêu cầu đồng ý lưu snapshot dữ liệu DAYMARK lên Cloud để đồng bộ. Chỉ xác nhận khi bạn hiểu rằng dữ liệu công việc, mục tiêu, thói quen, ghi chú, nhật ký, phiên tập trung và dữ liệu RPG được lưu trong tài khoản cloud của bạn.
3. Nếu tài khoản Cloud đã có dữ liệu, ứng dụng sẽ hỏi dùng dữ liệu trên thiết bị hay dữ liệu Cloud. Tạo backup trước khi chọn.
4. Tạo một task thử trên máy tính và kiểm tra iPhone; sau đó hoàn thành task trên iPhone và kiểm tra máy tính.

## 5. AI và quyền riêng tư

AI chỉ hoạt động sau khi Edge Function đã được deploy và secrets được cấu hình. Mỗi lần hỏi AI, tự chọn từng nhóm dữ liệu và xác nhận gửi. Lịch sử chat mặc định không được gửi; muốn đưa tối đa sáu tin gần nhất vào prompt cần bật lựa chọn riêng. Không đưa API key hoặc dữ liệu nhạy cảm vào chat hay repository. Xem `SETUP_DAYMARK_3.0.md` để biết toàn bộ các bước backend.
