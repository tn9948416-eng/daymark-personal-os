# DAYMARK 3.1 — Validation report

## Checks completed in this build

- JavaScript inline bundle passes `node --check` (syntax validation).
- HTML parse completed; no duplicate static element IDs found.
- Navigation contains 13 pages, including `reminders`.
- Focus overlay root, manifest, service worker, notification handlers and calendar export code are present.
- Existing localStorage key `daymark-v2` remains unchanged.
- Task schema only gains optional `reminderAt` and `reminderSentAt` fields; older tasks without these fields remain valid.
- Paid OpenAI API invocation has been disabled in the UI/function path; no OpenAI key or AI Edge Function is included in this 3.1 package.
- Service worker cache name updated to `daymark-shell-v3.1.0`.

## Not verified on physical hardware

This environment blocked local browser navigation, so end-to-end browser automation could not be completed. The following still require manual testing on the user's devices: iPhone Home Screen PWA behavior, iOS notification permission, actual Wake Lock grant, audio output at timer completion, and import of `.ics` events into Apple Calendar. Cloud Sync also requires the user's Supabase configuration and is not part of these local feature checks.

## Platform limitations

- Screen Wake Lock only helps while the DAYMARK Home Screen app is visible in the foreground and the browser/device grants the lock. Manually pressing the power button or switching away can suspend the app.
- A web app cannot directly toggle iOS Do Not Disturb/Focus. The user must enable it in Control Center or configure an iOS Focus schedule.
- Without a Web Push sender/server, DAYMARK's own scheduled reminders are checked while the app is running or when reopened. For reminders while the app is fully closed, export the task to `.ics` and add it to Apple Calendar.
- A web app cannot show a live timer on iPhone Lock Screen or Dynamic Island; that requires a native iOS app with Live Activities.
