/*
 * DAYMARK 3.0 — public Supabase browser configuration.
 * Safe to publish ONLY the Project URL and the publishable/anon key here.
 * NEVER put service_role, secret keys, or OPENAI_API_KEY in this file.
 */
window.DAYMARK_CONFIG = Object.freeze({
  SUPABASE_URL: '',        // Example: https://YOUR_PROJECT_REF.supabase.co
  SUPABASE_ANON_KEY: ''    // Supabase publishable key (sb_publishable_...) or legacy anon key
});
