# DAYMARK 3.1 — Focus & Reminders

A no-paid-AI update to DAYMARK 3.0, focused on deep-work sessions and task reminders. It preserves the existing localStorage key (`daymark-v2`) and current task/session data so previous local data remains readable.

## New in 3.1

- Full-viewport Deep Work screen with an atmospheric dark background, progress ring, motivational copy, pause/resume and completion state.
- Deadline-based timer so remaining time is recalculated from an absolute deadline when the app becomes visible again.
- Screen Wake Lock where the device/browser supports it. On iPhone, use the Home Screen app; iOS/iPadOS 18.4+ supports Wake Lock in Home Screen web apps. It can prevent auto-dimming while DAYMARK remains visible, but it cannot prevent a user from manually locking the phone.
- Completion chime using Web Audio where allowed, plus a system notification if permission has been granted.
- Optional per-task reminder date/time, a reminder center, a notification permission button, due checks while DAYMARK is running, and `.ics` export with calendar alerts.
- Paid AI/API integration is paused. The Coach page uses local rules only and no OpenAI API key is needed.

## Important iPhone limits

- DAYMARK cannot automatically turn iOS Do Not Disturb/Focus on or off. Enable it manually from Control Center → Focus → Do Not Disturb, or configure a schedule in iOS Settings.
- If you manually lock the iPhone, the PWA cannot keep showing its live timer on the Lock Screen/Dynamic Island. That requires a native iOS app with Live Activities.
- Without a Web Push sending service, DAYMARK itself checks reminders only while it is running or when you reopen it. For a reminder while DAYMARK is fully closed, add the exported `.ics` event to Apple Calendar; Calendar then handles the system alert.
- On iPhone, run DAYMARK from its Home Screen icon for the standalone PWA experience. The focus overlay fills the app viewport; Safari does not provide a reliable general full-screen API for arbitrary page elements.

## Update existing GitHub Pages deployment

1. Back up DAYMARK data separately on your computer and iPhone (Settings → Export JSON). Never upload personal JSON backups to a public repository.
2. Extract this ZIP.
3. In GitHub repository `daymark-personal-os`, replace the root files with the files from this folder: `index.html`, `sw.js`, `manifest.webmanifest`, icons, `supabase-config.js`, `.nojekyll` and the updated README if desired.
4. Do not upload personal backup files or secrets. Keep `supabase-config.js` unchanged if you already configured optional Cloud Sync.
5. Commit to `main`, wait for GitHub Pages deployment, then close/reopen DAYMARK on desktop and on iPhone from its Home Screen icon.
6. Open DAYMARK → Nhắc việc → Bật thông báo and grant permission. On iPhone, launch the installed Home Screen app first.
7. Create/edit a task and set **Nhắc vào thời điểm**. Use **Thêm vào Lịch** or **Xuất tất cả sang Lịch (.ics)** for an OS-level alert when DAYMARK is closed.

## Focus mode

Open **Tập trung**, choose 15/25/45/60 minutes, enter an optional label, and tap **Bắt đầu tập trung**. Keep DAYMARK in the foreground and do not press the iPhone power button if you want the timer visible. If Wake Lock is supported and granted, DAYMARK asks the device not to auto-sleep. Enable Do Not Disturb manually when needed.

## Privacy and cost

This update does not call the OpenAI API and needs no paid AI subscription. Existing optional Supabase Cloud Sync remains available if it was configured; the focus and reminder features work locally without it.
