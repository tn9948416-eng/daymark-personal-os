# DAYMARK 3.0 — triển khai Cloud Sync + AI

Phiên bản này giữ nguyên toàn bộ ứng dụng 2.1 và bổ sung lớp kết nối. Chưa có Supabase/OpenAI credential nên **không thể tự kết nối Cloud hoặc chạy AI cho tới khi chủ tài khoản tự cấu hình**.

## 0. Bảo toàn dữ liệu trước khi nâng cấp

1. Mở DAYMARK 2.1 trên mọi thiết bị và vào **Cài đặt → Xuất dữ liệu (.json)**. Giữ file sao lưu riêng tư.
2. Không xóa bản 2.1 cũ. Trong gói này, `archive/index.v2.1-preserved.html` là bản HTML 2.1 được giữ nguyên để tham chiếu; các file icon/PWA 2.1 cũng được giữ.
3. Bản 3.0 vẫn đọc khóa localStorage `daymark-v2` (và fallback `daymark-v1`). Khi đăng nhập Cloud lần đầu, ứng dụng tạo recovery snapshot trước khi tải dữ liệu Cloud về.
4. Lần đầu đăng nhập trên thiết bị đã có dữ liệu Cloud, DAYMARK hỏi chọn dữ liệu thiết bị hay Cloud; không âm thầm ghi đè.

## 1. Tạo dự án Supabase

1. Mở [Supabase](https://supabase.com/) và tạo project mới. Đặt mật khẩu database mạnh; lưu ở trình quản lý mật khẩu cá nhân, không đưa vào GitHub.
2. Chờ project được tạo xong, mở **Project Settings → API** (hoặc mục API Keys tùy giao diện).
3. Sao chép **Project URL** và **Publishable key** (`sb_publishable_...`) hoặc legacy `anon` key. Đây là thông tin công khai để trình duyệt khởi tạo SDK; quyền truy cập dữ liệu được khóa bằng RLS. **Không sao chép secret key hoặc service_role key.**
4. Mở `supabase-config.js` ở thư mục gốc. Điền hai giá trị:

```js
window.DAYMARK_CONFIG = Object.freeze({
  SUPABASE_URL: 'https://YOUR_PROJECT_REF.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR_PUBLISHABLE_OR_ANON_KEY'
});
```

5. Tải file `supabase-config.js` cùng các file DAYMARK khác lên thư mục gốc GitHub Pages. Vì đây là publishable/anon key, việc nó xuất hiện trong source website là dự kiến; **không bao giờ đặt service role key hay OpenAI key ở đây**.

## 2. Tạo bảng và chính sách bảo mật

1. Trong Supabase Dashboard, mở **SQL Editor → New query**.
2. Mở file `supabase/migrations/001_daymark_cloud.sql` trong VS Code, sao chép toàn bộ nội dung và chạy một lần trong SQL Editor.
3. Mở **Database → Tables**. Kiểm tra thấy `daymark_states` và `daymark_ai_usage`.
4. Bảng `daymark_states` bật Row Level Security. Policy cho phép người dùng chỉ đọc bản ghi có `user_id = auth.uid()`. Client không được INSERT/UPDATE trực tiếp; mọi lần ghi đi qua RPC `save_daymark_state`, hàm kiểm tra `auth.uid()` và compare-and-swap theo `updated_at` để phát hiện xung đột phiên bản.
5. Kiểm tra Realtime được bật cho bảng `daymark_states` trong **Database → Publications/Realtime** nếu event cập nhật chưa được bật tự động.

**Kiểm tra an toàn:** không tắt RLS; không cấp quyền bảng cho `anon`; không dùng `service_role` trong browser. Migration đã tạo grant/policy cần thiết.

## 3. Bật đăng nhập email

1. Supabase Dashboard → **Authentication → Providers → Email**.
2. Bật Email provider.
3. Với thử nghiệm đầu tiên, có thể giữ xác nhận email bật. Khi đăng ký, mở hộp thư và xác nhận trước khi đăng nhập.
4. Authentication → URL Configuration: đặt Site URL thành `https://tn9948416-eng.github.io/daymark-personal-os/`. Thêm URL này vào Redirect URLs nếu Supabase yêu cầu.
5. Tải lại website sau khi file config được publish. Vào **Cài đặt → DAYMARK Cloud Sync → Đăng nhập / tạo tài khoản**.
6. Dùng cùng email/password ở máy tính và iPhone. Khi thiết bị thứ hai có dữ liệu cục bộ riêng, hộp thoại sẽ cho chọn tải Cloud về hoặc giữ dữ liệu thiết bị để đẩy lên Cloud.

## 4. Cách đồng bộ hoạt động

- Mỗi lần thay đổi, DAYMARK vẫn lưu ngay trong localStorage trước. Sau khoảng 1.3 giây, nếu online và đăng nhập, app gọi hàm `save_daymark_state`.
- Supabase lưu một snapshot JSON riêng cho `auth.uid()`; RLS giới hạn truy cập theo tài khoản.
- Realtime nhận cập nhật từ thiết bị khác và thay state khi thiết bị hiện tại không có thay đổi chờ gửi.
- Nếu hai thiết bị chỉnh sửa cùng lúc, app hỏi bạn chọn: **dùng Cloud** hoặc **giữ thiết bị này và ghi lên Cloud**. Hộp thoại này là lựa chọn có ý thức để tránh mất dữ liệu.
- Khi offline, thay đổi vẫn ở localStorage; app thử gửi lại khi thiết bị online. Hãy giữ thói quen xuất backup định kỳ.
- Đăng xuất không xóa localStorage trên thiết bị.

## 5. AI setup — OpenAI API được bảo vệ ở server

**Không đặt OpenAI API key trong `index.html`, `supabase-config.js`, GitHub, hay biến JavaScript trình duyệt.** OpenAI khuyến nghị không triển khai khóa API trong môi trường client-side. Khóa được đặt thành Supabase Edge Function Secret.

### Tạo Edge Function

Cách A — dùng Supabase CLI:

1. Cài [Supabase CLI](https://supabase.com/docs/guides/cli) theo tài liệu chính thức.
2. Mở terminal trong thư mục `DAYMARK-3.0`.
3. Đăng nhập và liên kết project:

```bash
supabase login
supabase link --project-ref YOUR_PROJECT_REF
```

4. Deploy function:

```bash
supabase functions deploy daymark-ai
```

5. Tạo file `.env` cục bộ từ mẫu, chỉnh các giá trị thật rồi đẩy lên Supabase. File `.env` được `.gitignore` bảo vệ; tuyệt đối không commit file này:

```powershell
Copy-Item supabase/functions/.env.example supabase/functions/.env
# Mở supabase/functions/.env và điền API key thật
supabase secrets set --env-file supabase/functions/.env
```

Cách B — dùng Dashboard nếu giao diện project có trình chỉnh sửa/deploy Edge Functions. Tạo function tên `daymark-ai` và đưa nội dung từ `supabase/functions/daymark-ai/index.ts` vào; cấu hình secrets tại **Edge Functions → Secrets**. Đảm bảo `verify_jwt = true`.

6. Tạo API key trong OpenAI API Platform và thiết lập billing/usage limit phù hợp. API tính phí riêng, không mặc định đi kèm gói ChatGPT.
7. Trong Supabase → Edge Functions → Secrets, bắt buộc thêm `OPENAI_API_KEY` và `DAYMARK_ALLOWED_ORIGIN=https://tn9948416-eng.github.io`. Origin chỉ gồm giao thức + tên miền, không thêm đường dẫn `/daymark-personal-os/`. Có thể đặt `OPENAI_MODEL=gpt-6-luna` hoặc chọn model khác đang được bật trong API project. Không chia sẻ API key với bất kỳ ai. Function sẽ từ chối yêu cầu khi chưa cấu hình origin được phép hoặc origin không khớp.
8. Thử AI từ trang **AI Life Coach** sau khi đăng nhập. Mỗi yêu cầu phải chọn ít nhất một nhóm dữ liệu và đánh dấu đồng ý. Bản starter giới hạn mặc định 15 lượt/ngày/tài khoản qua RPC quota.

**Tuổi và tài khoản:** việc tạo, quản lý tài khoản API và billing phải tuân thủ điều kiện tuổi/điều khoản hiện hành của nhà cung cấp. Nếu người dùng chưa đủ tuổi, cha mẹ/người giám hộ cần hỗ trợ quản lý tài khoản và thanh toán; không khai sai tuổi hoặc tìm cách bỏ qua giới hạn.

## 6. Quyền riêng tư của AI

- Các nhóm `profile`, `tasks`, `goals`, `habits`, `focus`, `notes`, `journal` đều mặc định **không được chọn**.
- Mỗi lần gọi phải tick consent. Request chỉ mang các khóa dữ liệu tương ứng với nhóm được chọn; Edge Function kiểm tra lựa chọn và từ chối key không được phép.
- Nhật ký/ghi chú có thể chứa nội dung riêng tư. Chỉ chọn nếu thực sự cần cho câu hỏi.
- Prompt và nhóm dữ liệu được chọn được gửi qua Supabase Edge Function sang OpenAI. Dùng `store: false` cho Responses API; điều này không đồng nghĩa mọi dữ liệu được miễn khỏi chính sách lưu giữ/giám sát của các nhà cung cấp. Xem chính sách dữ liệu hiện hành của Supabase và OpenAI trước khi dùng dữ liệu nhạy cảm.
- Hội thoại chỉ giữ trong bộ nhớ trang hiện tại, không được DAYMARK ghi vào bảng cloud. Mỗi lần gọi, lịch sử hội thoại mặc định không được gửi; muốn gửi tối đa 6 tin nhắn gần nhất, phải bật ô đồng ý riêng cho lịch sử hội thoại.
- Không gửi mật khẩu, mã OTP, dữ liệu tài chính, địa chỉ nhà hoặc dữ liệu sức khỏe nhạy cảm.

## 7. Publish lên GitHub Pages

Đưa các file cần thiết sau vào thư mục gốc repo GitHub Pages:

- `index.html`
- `supabase-config.js`
- `manifest.webmanifest`
- `sw.js`
- `icon.svg`, `icon-180.png`, `icon-192.png`, `icon-512.png`
- `.nojekyll`
- Các file SQL/function có thể giữ trong repo để version control, nhưng không upload `.env` hay backup JSON.

Sau commit, chờ GitHub Pages build xong. Trên iPhone mở URL HTTPS bằng Safari rồi kéo xuống để refresh hoặc đóng và mở lại PWA. Nếu app cũ bị cache, đóng PWA, mở site Safari, refresh hai lần; service worker 3.0 sẽ thay cache cũ.

## 8. Kiểm tra sau khi triển khai

1. Đăng ký/đăng nhập trên desktop.
2. Vào Settings, kiểm tra trạng thái `Đã đồng bộ`.
3. Tạo một task thử tên `SYNC TEST - delete me` trên desktop.
4. Mở DAYMARK trên iPhone bằng cùng tài khoản, đợi realtime; task cần xuất hiện.
5. Đánh dấu task hoàn thành trên iPhone; desktop phải cập nhật.
6. Xóa task thử và xác nhận trạng thái cập nhật.
7. Thử AI với chỉ nhóm `tasks` được chọn và consent đã đánh dấu. Sau đó thử bỏ consent; app phải không gửi request.
8. Thử offline: thay đổi vẫn lưu cục bộ. Khi online, status chuyển về đang đồng bộ rồi đã đồng bộ.
9. Tải backup JSON riêng tư trên cả thiết bị trước khi sử dụng hằng ngày.

## 9. Giới hạn minh bạch của bản starter

- Đây là bản tích hợp kiến trúc sẵn sàng triển khai, không thể tự tạo project Supabase, xác minh email, tạo OpenAI API key hoặc bật billing thay bạn.
- Chưa có merge theo từng trường/từng bản ghi; khi phát hiện xung đột, bạn chọn toàn bộ snapshot Cloud hoặc snapshot thiết bị. Hãy tránh sửa cùng lúc trên hai thiết bị trong lần đầu. Nếu trình duyệt không thể tạo bản sao lưu phục hồi, ứng dụng sẽ từ chối thay dữ liệu cục bộ bằng dữ liệu Cloud.
- Chưa có xóa tài khoản từ UI; quản lý tài khoản qua Supabase Auth Dashboard.
- AI có giới hạn quota 15 lượt/ngày, phản hồi cần được kiểm chứng và AI không tự thực hiện task actions. OpenAI API có billing tách biệt với ChatGPT; hãy để cha mẹ/người giám hộ quản lý tài khoản API và thanh toán nếu bạn chưa đủ tuổi theo điều khoản dịch vụ.
- Khi đã đăng nhập, toàn bộ state ứng dụng (kể cả journal/notes) nằm trong snapshot riêng Cloud để đồng bộ. AI chỉ nhận các trường được chọn và consent theo từng lần gửi.
